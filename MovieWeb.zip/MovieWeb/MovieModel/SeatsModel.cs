﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieModel
{
    public class SeatsModel
    {
        public string hall_id { set; get; }
        public int x { set; get; }
        public int y { set; get; }
        public int seats_id { set; get; }
        public int flag { get; set; }
    }
}
