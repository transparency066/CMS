﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieModel
{
    public class 用户
    {
        public string 账号ID { get; set; }
        public string 昵称 { get; set; }
        public string 电话 { get; set; }
        public int 性别 { get; set; }
    }
}
