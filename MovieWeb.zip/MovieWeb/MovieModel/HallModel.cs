﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieModel
{
    public class HallModel
    {
        public string hall_id { set; get; }
        public int total { set; get; }
        public string location { set; get; }
    }
}
