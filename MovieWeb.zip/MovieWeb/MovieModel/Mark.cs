﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieModel
{
    public class Mark
    {
        public string ticketID { get; set; }
        public string userID { get; set; }
        public string score { get; set; }
    }
}
