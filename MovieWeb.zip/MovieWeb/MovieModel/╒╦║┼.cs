﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieModel
{
    public class 账号
    {
        public int 账号ID { get; set; }
        public int 密码 { get; set; }
        public int 权限 { get; set; }
    }
}
