﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MovieWeb.Models
{
    public class AllUListViewModel
    {
        public List<Account> AllUs { get; set; }
        public int Count { get; set; }
    }
}