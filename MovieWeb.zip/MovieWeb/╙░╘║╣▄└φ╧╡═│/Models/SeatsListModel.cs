﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MovieModel;

namespace MovieWeb.Models
{
    public class SeatsListModel
    {
        public List<SeatsModel> SeatsList { set; get; }
    }
}