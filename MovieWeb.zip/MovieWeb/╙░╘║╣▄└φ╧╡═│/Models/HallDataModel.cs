﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MovieWeb.Models
{
    public class HallDataModel
    {
        public string hall_id { set; get; }
        public int total { set; get; }
        public string location { set; get; }
    }
}